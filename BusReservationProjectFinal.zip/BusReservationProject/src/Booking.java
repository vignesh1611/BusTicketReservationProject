import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

public class Booking {

	String passengerName;
	int age;
	int pId;
	int busNo;
	String date;

	Scanner scan = new Scanner(System.in);

	public Booking() {

		System.out.println("Enter the Passenger name : ");
		passengerName = scan.next();
		System.out.println("Enter the Passenger age : ");
		age = scan.nextInt();
		System.out.println("Enter the PassengerId : ");
		pId = scan.nextInt();
		System.out.println("Enter the Bus No. : ");
		busNo = scan.nextInt();
		System.out.println("Enter the Date of travel (dd-mm-yyyy) : ");
		System.out.println("Enter the Date : ");
		date = scan.next();
		SimpleDateFormat sdf1 = new SimpleDateFormat("dd-MM-yyyy");
		java.util.Date udob;
		try {
			udob = sdf1.parse(date);
			java.sql.Date sqdob = new java.sql.Date(udob.getTime());
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

	public String getPassengerName() {
		return passengerName;
	}

	public void setPassengerName(String passengerName) {
		this.passengerName = passengerName;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public int getpId() {
		return pId;
	}

	public void setpId(int pId) {
		this.pId = pId;
	}

	public int getBusNo() {
		return busNo;
	}

	public void setBusNo(int busNo) {
		this.busNo = busNo;
	}

	public String getDate() {
		return date;
	}

	public void setDate(String date) {
		this.date = date;
	}

	@Override
	public String toString() {
		return "Booking [passengerName=" + passengerName + ", age=" + age + ", pId=" + pId + ", busNo=" + busNo
				+ ", date=" + date + "]";
	}

}
