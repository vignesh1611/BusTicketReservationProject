import java.sql.*;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

public class Admin {

	String passengerName;
	int age;
	int pId;
	int busNo;
	String date;
	int available;
	int booked = 0;
	Connection con = null;

	PreparedStatement stmt = null;
	Scanner scan = new Scanner(System.in);
	Booking booking;

	List<Bus> list = new ArrayList<>();
	Bus busdetails = new Bus();
	Ticket ticket = new Ticket();

	public Admin() throws SQLException, ParseException {
		DBProperties db = new DBProperties();

		con = DriverManager.getConnection(db.getUrl(), db.getUserName(), db.getPassword());
	}

	void add() {
		int res;
		try {
			stmt = con.prepareStatement("insert into businfos values(?,?,?,?,?,?)");
			Bus bus = new Bus();

			char ch = 'y';
			do {

				System.out.println("Enter the Bus No: ");
				bus.setBusNo(scan.nextInt());
				System.out.println("Enter the AC/non-AC : ");
				bus.setAc(scan.next());
				System.out.println("Enter the capacity : ");
				bus.setCapacity(scan.nextInt());
				System.out.println("Enter the Fair: ");
				bus.setFair(scan.nextDouble());
				System.out.println("Enter the Destination: ");
				bus.setDestination(scan.next());
				System.out.println("Enter the Date(dd-MM-yyyy) : ");
				date = scan.next();
				SimpleDateFormat sdf1 = new SimpleDateFormat("dd-MM-yyyy");
				java.util.Date udob;
				try {
					udob = sdf1.parse(date);
					java.sql.Date sqdob = new java.sql.Date(udob.getTime());
					stmt.setInt(1, bus.getBusNo());
					stmt.setString(2, bus.getAc());
					stmt.setInt(3, bus.getCapacity());
					stmt.setDate(4, sqdob);
					stmt.setDouble(5, bus.getFair());
					stmt.setString(6, bus.getDestination());
				} catch (ParseException e) {
					// TODO Auto-generated catch block
					System.out.println("Enter date is valid format");
				}

				res = stmt.executeUpdate();
				if (res == 1) {
					System.out.println("executed");
				} else {
					System.out.println("not executed");
				}

				System.out.println("Do you want to continue");
				ch = scan.next().charAt(0);
			} while (ch == 'y');
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			System.out.println("Enter the Valid Detials in valid format");
		}

	}

	public List<Bus> display() {
		// TODO Auto-generated method stub
		try {
			stmt = con.prepareStatement("select *from businfos");
			ResultSet rs = stmt.executeQuery();

			while (rs.next()) {
				busdetails.setBusNo(rs.getInt("busNo"));
				busdetails.setAc(rs.getString("ac"));
				busdetails.setCapacity(rs.getInt("capactity"));
				busdetails.setDate(rs.getDate("date"));
				busdetails.setFair(rs.getDouble("Fair"));
				busdetails.setDestination(rs.getString("destination"));
				list.add(busdetails);
				System.out.println("----------------------------------------------------------------------- ");
				System.out.print("BUS NO:" + busdetails.getBusNo() + "|");
				System.out.print("IS AC:" + busdetails.getAc() + "| ");
				System.out.print("SEAT AVAILABLE: " + busdetails.getCapacity() + "| ");
				System.out.print("Date: " + busdetails.getDate() + "| ");
				System.out.print("DESTINATION :" + busdetails.getDestination() + "| ");
				System.out.print("FAIR: " + busdetails.getFair() + "| ");

				System.out.println();
				System.out.println("----------------------------------------------------------------------");
			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			System.out.println("Enter the Valid Details");
		}

		return null;
	}

	public boolean bookings() throws ParseException {
		Booking booking = new Booking();
		boolean book = false;

		SimpleDateFormat sdf2 = new SimpleDateFormat("yyyy-MM-dd");

		try {
			stmt = con.prepareStatement("select *from businfos where date = ? && busNo=? ");
			stmt.setString(1, booking.date);
			stmt.setInt(2, booking.busNo);

			ResultSet rs = stmt.executeQuery();
			rs.next();
			busdetails.setBusNo(rs.getInt("busNo"));
			busdetails.setCapacity(rs.getInt("capactity"));
			busdetails.setDate(rs.getDate("date"));
			busdetails.setFair(rs.getDouble("Fair"));
			available = busdetails.getCapacity();
			System.out.print("| " + "BUS CAPACITY: " + busdetails.getCapacity() + "/ ");
			System.out.print("Date: " + busdetails.getDate() + "| ");
			String dt = sdf2.format(busdetails.getDate());
			System.out.println();
			if (busdetails.getCapacity() > 0) {
				if (busdetails.getBusNo() == booking.busNo && (booking.date.equals(dt))) {
					available--;
					booked++;
					stmt = con.prepareStatement("update businfos set capactity=? where busNo=? && date=? ");
					stmt.setInt(1, available);
					stmt.setInt(2, booking.busNo);
					stmt.setString(3, booking.date);

					stmt.executeUpdate();
					book = true;
					System.out.println("Booked Succesfully...");

					/*stmt = con.prepareStatement("insert into passengerdetails values(?,?,?,?)");
					stmt.setString(1, booking.passengerName);
					stmt.setInt(2, booking.pId);*/
					

					stmt = con.prepareStatement("insert into bookings values(?,?,?,?,?,?)");
					stmt.setInt(1, booking.pId);
					stmt.setString(2, booking.passengerName);
					stmt.setInt(3, booking.busNo);
					stmt.setString(4, booking.date);
					stmt.setInt(5, booking.age);
					stmt.setDouble(6, rs.getDouble("Fair"));

					int res = stmt.executeUpdate();

				} else {
					System.out.println("fails");
				}
			} else {
				System.out.println("No seats available for booking on this date ...");
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			System.out.println("Enter the Valid Booking Details");
		}

		return book;
	}

	public void cancellation() throws SQLException {

		Booking booking = new Booking();
		BookedDetails bookeddetails = new BookedDetails();

		SimpleDateFormat sdf2 = new SimpleDateFormat("yyyy-MM-dd");

		try {

			stmt = con.prepareStatement("select *from businfos where date = ? && busNo=? ");
			stmt.setString(1, booking.date);
			stmt.setInt(2, booking.busNo);

			ResultSet rs = stmt.executeQuery();
			rs.next();
			busdetails.setBusNo(rs.getInt("busNo"));
			busdetails.setCapacity(rs.getInt("capactity"));
			busdetails.setDate(rs.getDate("date"));

			stmt = con.prepareStatement("select *from bookings where date = ? && busNo=? && p_Id=?");
			stmt.setString(1, booking.date);
			stmt.setInt(2, booking.busNo);
			stmt.setInt(3, booking.pId);
			rs = stmt.executeQuery();
			rs.next();
			ticket.setBusNo(rs.getInt("busNo"));
			ticket.setpId(rs.getInt("p_Id"));
			ticket.setDate(rs.getString("date"));

			available = busdetails.getCapacity();
			System.out.println();
			if (ticket.getpId() == booking.pId) {
				if (ticket.getBusNo() == booking.busNo && (booking.date.equals(ticket.getDate()))) {
					available++;
					booked--;
					stmt = con.prepareStatement("update businfos set capactity=? where busNo=? && date=? ");
					stmt.setInt(1, available);
					stmt.setInt(2, booking.busNo);
					stmt.setString(3, booking.date);

					stmt.executeUpdate();
					stmt = con.prepareStatement("delete from bookings where busNo=? && date=? && p_Id=?");

					stmt.setInt(1, booking.busNo);
					stmt.setString(2, booking.date);
					stmt.setInt(3, booking.pId);

					int re = stmt.executeUpdate();

					System.out.println("Cancelled Succesfully...");
				} else {
					System.out.println("Id is Not correct");
				}

			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			System.out.println("Enter the Valid details for cancellation");
		}
	}

	public void updateBus(int capacities, int busnum, String dates) throws SQLException {
		// TODO Auto-generated method stub

		stmt = con.prepareStatement("update businfos set capactity=? where busNo=? && date=?");

		stmt.setInt(1, capacities);
		stmt.setInt(2, busnum);
		stmt.setString(3, dates);

		int re = stmt.executeUpdate();
		if (re == 1) {
			System.out.println("updated succesfully");
		} else {
			System.out.println("not update");
		}
	}

	public void updateBusFair(Double Fair, int busnum, String dates) throws SQLException {
		// TODO Auto-generated method stub

		stmt = con.prepareStatement("update businfos set Fair=? where busNo=? && date=?");

		stmt.setDouble(1, Fair);
		stmt.setInt(2, busnum);
		stmt.setString(3, dates);

		int re = stmt.executeUpdate();
		if (re == 1) {
			System.out.println("updated succesfully");
		} else {
			System.out.println("not update");
		}
	}

	public void deleteBus(int busnum, String dates) throws SQLException {
		// TODO Auto-generated method stub

		stmt = con.prepareStatement("delete from businfos  where busNo=? && date=?");

		stmt.setInt(1, busnum);
		stmt.setString(2, dates);

		int re = stmt.executeUpdate();
		if (re == 1) {
			System.out.println("deleted succesfully");
		} else {
			System.out.println("not deleted");
		}

	}

	public void viewUserDetails() throws SQLException {
		stmt = con.prepareStatement("select *from logindetails");
		ResultSet rs = stmt.executeQuery();

		List<UserDetails> list = new ArrayList<>();
		UserDetails userdetails = new UserDetails();
		while (rs.next()) {

			userdetails.setUserName(rs.getString("userName"));
			userdetails.setPassWord(rs.getInt("PASSWORD"));
			userdetails.setEmailId(rs.getString("EMAILID"));
			list.add(userdetails);

			System.out.print("| User Name :" + userdetails.getUserName() + " | ");
			System.out.print("Password :" + userdetails.getPassWord() + " | ");
			System.out.print("Email Id : " + userdetails.getEmailId() + " | ");
			System.out.println();
		}
	}

	public void viewTicket(int p_id) {
		Ticket ticket = new Ticket();

		try {
			stmt = con.prepareStatement("select *from bookings where p_Id=?");
			stmt.setInt(1, p_id);
			ResultSet rs = stmt.executeQuery();
			rs.next();
			ticket.setPassengerName(rs.getString("passengerName"));
			ticket.setAge(rs.getInt("p_Age"));
			ticket.setpId(rs.getInt("p_Id"));
			ticket.setFair(rs.getDouble("Fair"));
			ticket.setBusNo(rs.getInt("busNo"));
			ticket.setDate(rs.getString("date"));
			System.out.println("***************************************");
			System.out.println("**               TICKET              **");
			System.out.println("***************************************");
			System.out.println("PASSENGER'S NAME: " + ticket.getPassengerName());
			System.out.println("PASSENGER'S Age : " + ticket.getAge());
			System.out.println("PASSENGER'S Id No. : " + ticket.getpId());
			System.out.println("BUS  No. : " + ticket.getBusNo());
			System.out.println("TRAVELL DATE : " + ticket.getDate());
			System.out.println("FARE PRICE: " + ticket.getFair() + " per ticket");
			System.out.println("***************************************");
			System.out.println("***************************************");

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			System.out.println("Enter valid Passenger ID");;
		}



	}

}
