import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

public class Login {

	Connection con = null;

	PreparedStatement stmt = null;
	Scanner scan = new Scanner(System.in);

	public Login() throws SQLException {
		DBProperties db = new DBProperties();

		con = DriverManager.getConnection(db.getUrl(), db.getUserName(), db.getPassword());
	}

	public void usersignUp() {
		UserDetails userdetails = new UserDetails();
		int res;
		try {
			stmt = con.prepareStatement("insert into logindetails values(?,?,?)");

			System.out.println("Enter the User Name : ");
			userdetails.setUserName(scan.next());
			System.out.println("Enter the Password : ");
			userdetails.setPassWord(scan.nextInt());
			System.out.println("Enter the Email Id : ");
			userdetails.setEmailId(scan.next());

			stmt.setString(1, userdetails.getUserName());
			stmt.setInt(2, userdetails.getPassWord());
			stmt.setString(3, userdetails.getEmailId());

			if ((userdetails.getUserName().length() > 8) && (userdetails.getPassWord() > 8)) {

				res = stmt.executeUpdate();
				if (res == 1) {
					System.out.println("executed");
				} else {
					System.out.println("not executed");
				}
			} else {
				System.out.println("User name and password should be above 8 characters...");
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			System.out.println("Admin name and password should be proper format...");
		}

	}

	public boolean usersignIn(String userName, int passWord) {

		boolean matches = false;
		UserDetails userdetails = new UserDetails();
		try {
			stmt = con.prepareStatement("select *from logindetails where userName = ? && passWord=? ");
			stmt.setString(1, userName);
			stmt.setInt(2, passWord);
			ResultSet rs = stmt.executeQuery();
			rs.next();
			userdetails.setUserName(rs.getString("userName"));
			userdetails.setPassWord(rs.getInt("passWord"));
			userdetails.setEmailId(rs.getString("emailId"));
			System.out.println();
			matches = true;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			System.out.println("Enter the valid user name and password");
		}

		return matches;

	}

	public void adminSignUp() {

		AdminDetails admindetails = new AdminDetails();
		int res;
		try {
			stmt = con.prepareStatement("insert into admindetails values(?,?,?)");

			System.out.println("Enter the User Name : ");
			admindetails.setUserName(scan.next());
			System.out.println("Enter the Password : ");
			admindetails.setPassWord(scan.nextInt());
			System.out.println("Enter the Email Id : ");
			admindetails.setEmailId(scan.next());

			stmt.setString(1, admindetails.getUserName());
			stmt.setInt(2, admindetails.getPassWord());
			stmt.setString(3, admindetails.getEmailId());

			if ((admindetails.getUserName().length() > 8) && (admindetails.getPassWord() > 8)) {

				res = stmt.executeUpdate();
				if (res == 1) {
					System.out.println("executed");
				} else {
					System.out.println("not executed");
				}
			} else {
				System.out.println("User name and password should be above 8 characters...");
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			System.out.println("User name and password should be proper format...");
		}

	}

	public boolean adminsignIn(String userName, int passWord) {

		boolean matches = false;
		AdminDetails admindetails = new AdminDetails();
		try {
			stmt = con.prepareStatement("select *from admindetails where userName = ? && passWord=? ");
			stmt.setString(1, userName);
			stmt.setInt(2, passWord);
			ResultSet rs = stmt.executeQuery();
			rs.next();
			admindetails.setUserName(rs.getString("userName"));
			admindetails.setPassWord(rs.getInt("passWord"));
			admindetails.setEmailId(rs.getString("emailId"));
			System.out.println();
			matches = true;
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			System.out.println("Enter the valid user name and password");
		}

		return matches;

	}

}
