
public class UserDetails {

	String userName;
	int passWord;
	String emailId;

	public UserDetails() {

	}

	public UserDetails(String userName, int passWord, String emailId) {
		super();
		this.userName = userName;
		this.passWord = passWord;
		this.emailId = emailId;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public int getPassWord() {
		return passWord;
	}

	public void setPassWord(int passWord) {
		this.passWord = passWord;
	}

	public String getEmailId() {
		return emailId;
	}

	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}

	@Override
	public String toString() {
		return "UserDetails [userName=" + userName + ", passWord=" + passWord + ", emailId=" + emailId + "]";
	}

}
