import java.sql.Date;

public class BookedDetails {

	String passengerName;
	int pId;
	int busNo;
	Date date;

	public BookedDetails() {
		super();
		// TODO Auto-generated constructor stub
	}

	public String getPassengerName() {
		return passengerName;
	}

	public void setPassengerName(String passengerName) {
		this.passengerName = passengerName;
	}

	public int getpId() {
		return pId;
	}

	public void setpId(int pId) {
		this.pId = pId;
	}

	public int getBusNo() {
		return busNo;
	}

	public void setBusNo(int busNo) {
		this.busNo = busNo;
	}

	public Date getDate() {
		return date;
	}

	public void setDate(Date date) {
		this.date = date;
	}

	public BookedDetails(String passengerName, int pId, int busNo, Date date) {
		super();
		this.passengerName = passengerName;
		this.pId = pId;
		this.busNo = busNo;
		this.date = date;
	}

	@Override
	public String toString() {
		return "BookedDetails [passengerName=" + passengerName + ", pId=" + pId + ", busNo=" + busNo + ", date=" + date
				+ "]";
	}

}
